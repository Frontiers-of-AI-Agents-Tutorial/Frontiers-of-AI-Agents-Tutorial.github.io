This notebook has been authored by Tushar Dhadiwal `tudhadiw@microsoft.com` and Jenny Chen `jiech@microsoft.com` for education purposes only. 
- This is to be presented at CIKM conference in Oct 2024.
- Please go through the codebase before running any of the cells.
- Make sure to create a .env file with appropriate keys for OpenAI,Bing and Apify as needed.